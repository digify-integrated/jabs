<?php
session_start();
require '../api/dbconn.php';

// --- INPUT HANDLING ---
$table_num = [];
$order_id = null;
$payment_ref = null;

if (!empty($_GET['id'])) {
    $table_num = explode("_", $_GET['id']);
    $payment_ref = $_GET['r'] ?? null;
} elseif (!empty($_POST['id'])) {
    $table_num = explode("_", $_POST['id']);
} else {
    die("Invalid request. Table not specified.");
}

// --- TABLE INFO ---
$query_table = "SELECT name FROM table_category WHERE id = '".mysqli_real_escape_string($conn, $table_num[0])."'";
$row_table = mysqli_fetch_assoc(mysqli_query($conn, $query_table)) ?? ['name' => 'Unknown'];

$dateTime = "";
$cashier = "";
$total_items = 0;
$discount = 0;
$ticketdiscount = 0;
$amount_received = 0;
$rowdiscount = ['change'=>0,'discount_sc_pwd'=>0,'discount_tickets'=>0,'subtotal'=>0];

// --- BILLING QUERIES ---
if ($payment_ref) { // PRINT BILL
    $query = "
        SELECT o.user_id, o.created_at, p.name AS product_name, od.quantity, p.price, o.id AS order_id
        FROM orders o
        JOIN order_details od ON o.id = od.order_id
        JOIN products p ON p.id = od.product_id
        WHERE o.status = 1
          AND o.table_id = '".mysqli_real_escape_string($conn, $_GET['id'])."'
          AND o.payment_reference = '".mysqli_real_escape_string($conn, $payment_ref)."'
    ";

    $query2 = "
        SELECT * FROM payments 
        WHERE payment_reference = '".mysqli_real_escape_string($conn, $payment_ref)."'
    ";
    $rowdiscount = mysqli_fetch_assoc(mysqli_query($conn, $query2)) ?? $rowdiscount;
    

} else { // PREVIEW BILL
    $query = "
        SELECT o.user_id, o.created_at, p.name AS product_name, od.quantity, p.price, o.id AS order_id
        FROM orders o
        JOIN order_details od ON o.id = od.order_id
        JOIN products p ON p.id = od.product_id
        WHERE o.status = 0 
          AND o.table_id = '".mysqli_real_escape_string($conn, $_POST['id'])."'
    ";
}

$query_run = mysqli_query($conn, $query);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Print Receipt</title>
    <link rel="stylesheet" href="./css/stylePrint.css">
    <style>
        * { font-size:12px; font-family: Arial; }
        td, th, tr, table { border-collapse: collapse; }
        .ticket { width: 250px; max-width: 250px; }
        .centered { text-align: center; }
        @media print {
            .hidden-print { display:none !important; }
            body { -webkit-print-color-adjust: exact; }
        }
    </style>
    <script>
        window.print();
        window.onfocus = function(){ window.close(); }
    </script>
</head>
<body>
<div class="ticket">
    <p class="centered">
        <img src="../templates/img/logo2.png" alt="Logo" style="width:60%">
    </p>
    <p style="text-align:center;font-size:13px">
        MAHARLIKA HIGHWAY, LOMBOY, TALAVERA, NUEVA ECIJA<br>
        TIN NO: 490-693-381-00000
    </p>

<?php if (mysqli_num_rows($query_run) > 0): 
    $row_first = mysqli_fetch_assoc($query_run);
    mysqli_data_seek($query_run, 0);

    $row_cashier = mysqli_fetch_assoc(
        mysqli_query($conn, "SELECT name FROM users WHERE id = '".mysqli_real_escape_string($conn, $row_first['user_id'])."'")
    );

    $dateTime = $row_first['created_at'] ?? "";
    $cashier = $row_cashier['name'] ?? "N/A";
?>
    <?php if ($payment_ref): ?> 
        Transaction #: <?= htmlspecialchars($payment_ref) ?><br>
    <?php endif; ?>
    Table # <?= htmlspecialchars($row_table['name']." ".$table_num[1] ?? "") ?><br>
    Date Time: <?= htmlspecialchars($dateTime) ?><br>
    Cashier: <?= htmlspecialchars($cashier) ?><br><br>

    <table style="width:100%;">
        <tr style="border-top:1px solid black;border-bottom:1px solid black;">
            <td colspan="3" class="centered">
                <?= $payment_ref ? "ACKNOWLEDGEMENT RECEIPT" : "BILL" ?>
            </td>
        </tr>
        <?php foreach($query_run as $b): 
            $subtotal = (float)$b['price'] * (float)$b['quantity'];
            $total_items += $subtotal;  

            $amount_received = (float)($rowdiscount['subtotal'] ?? 0);
            $change  = (float)($rowdiscount['change'] ?? 0);

            $discount = $payment_ref 
                ? (float)($rowdiscount['discount_sc_pwd'] ?? 0) 
                : (float)($_POST['discountBill'] ?? 0);

            $ticketdiscount = $payment_ref 
                ? (float)($rowdiscount['discount_tickets'] ?? 0) 
                : (float)($_POST['ticketBill'] ?? 0);
        ?>
        <tr>
            <td style="width:10%;"><?= $b['quantity'] ?></td>
            <td style="width:70%;"><?= htmlspecialchars($b['product_name']) ?></td>
            <td style="width:20%;text-align:right;"><?= number_format($subtotal,2) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <hr>
<?php
    // --- COMPUTATIONS ---
    $vat_exempt = $discount / 1.12;
    $twenty_percent = $vat_exempt * 0.20;
    $vat_sales = ($total_items - $discount) / 1.12;
    $vat = $vat_sales * 0.12;
    $service_charge = $total_items * 0.10;
    $amount_due = ($vat_sales + $vat + $vat_exempt + $service_charge) - ($twenty_percent + $ticketdiscount);
?>
    <table style="width:100%;">
        <tr><td style="text-align:right;">SUBTOTAL:</td><td style="text-align:right;">P<?= number_format($total_items,2) ?></td></tr>
        <tr><td style="text-align:right;">VAT Sales:</td><td style="text-align:right;">P<?= number_format($vat_sales,2) ?></td></tr>
        <tr><td style="text-align:right;">VAT:</td><td style="text-align:right;">P<?= number_format($vat,2) ?></td></tr>
        <tr><td style="text-align:right;">SC:</td><td style="text-align:right;">P<?= number_format($service_charge,2) ?></td></tr>
        <?php if ($discount>0): ?>
        <tr><td style="text-align:right;">Less PWD/Senior Disc:</td><td style="text-align:right;">(P<?= number_format($twenty_percent,2) ?>)</td></tr>
        <?php endif; ?>
        <?php if ($ticketdiscount>0): ?>
        <tr><td style="text-align:right;">Less TICKET/S:</td><td style="text-align:right;">(P<?= number_format($ticketdiscount,2) ?>)</td></tr>
        <?php endif; ?>
        <tr><td style="text-align:right;">AMOUNT DUE:</td><td style="text-align:right;">P<?= number_format($amount_due,2) ?></td></tr>

        <?php if ($payment_ref): ?>  
        <tr><td style="text-align:right;">Amount Received:</td><td style="text-align:right;">P<?= number_format($amount_received,2) ?></td></tr>
        <tr><td colspan="2" style="text-align:right;">
            <?php
            $pay_query = "
                SELECT payment_method_id, amount FROM payment_methods
                WHERE table_id = '".mysqli_real_escape_string($conn, $_GET['id'])."'
                  AND payment_reference = '".mysqli_real_escape_string($conn, $payment_ref)."'
            ";
            $pay_run = mysqli_query($conn, $pay_query);
            while ($b = mysqli_fetch_assoc($pay_run)) {
                $label = match($b['payment_method_id']) {
                    "1" => "Cash",
                    "2" => "Gcash",
                    "3" => "Card",
                    "4" => "ENT",
                    default => "Other"
                };
                echo $label.": P".number_format((float)$b['amount'], 2)."<br>";
            }
            ?>
        </td></tr>
        <tr><td style="text-align:right;">Change:</td><td style="text-align:right;">P<?= number_format($rowdiscount['change'],2) ?></td></tr>
        <?php endif; ?>
    </table>

    <p class="centered" style="font-size:16px;">
        Thank you for your purchase.<br>
        This is NOT an OFFICIAL RECEIPT
    </p>
<?php endif; ?>
</div>
</body>
</html>
