<?php include 'header.php'; 

?>

<div class="container-xxl py-5 bg-dark mb-5" style="min-height: 100vh;">
           
 <!-- Menu Start -->
 <div class="container-xxl py-5">
            <div class="container" style="background-color: ghostwhite;">
                 <div class="text-center wow"  >
                    <h1 class="section-title ff-secondary text-center text-primary fw-normal">Transactions</h1>
                     <h4 class="mb-1">&nbsp;</h1>
                </div>
                <div class="tab-class text-center wow">
                
               
<?php
/*
STATUS
0-unpaid
1-paid
2-cancel
*/
date_default_timezone_set('Asia/Singapore');
$yesterday = date('Y-m-d 09:00:00', strtotime('-1 days')); 
$startDate="";
//$endDate = date('Y-m-d h:i:sa', strtotime(' -1 hours'));
$endDate =  date('Y-m-d H:i:s');
$date = date('Y-m-d ')." 00:00:00";
$d = DateTime::createFromFormat('Y-m-d H:i:s', $date);
$midnight = $d->getTimestamp();
$timeNow= time();
$diff = abs($midnight - $timeNow)/3600; ///hours
if($diff >=6){
   $startDate = date('Y-m-d ')." 09:00:00";//$now->toDateString() . " 10:00:00";
   //date today
}elseif( $diff <=4 ){   
   $startDate = $yesterday;//->toDateString() . " 10:00:00"; 4am
   //get date yesterday
}else{
   //OFF ito
   $startDate = $endDate;
}

//$query = "select * from orders WHERE created_at BETWEEN '". $startDate . "' AND '" . $endDate . "' AND user_id  = '". $_SESSION['user_id'] ."'";
//$query = "select * from  orders WHERE created_at BETWEEN '". $startDate . "' AND '" . $endDate . "' ";
//var_dump($query);

//Password before void
if(isset($_POST) && isset($_POST['txtPassword'])){
    $pass= $_POST['txtPassword'];
    $query = "SELECT * FROM users WHERE id='1'";
    $result = mysqli_query($conn,$query);
    $num_rows = mysqli_num_rows($result);
    $row_name = $result->fetch_assoc();
    if($num_rows >= 1){
        $user_id = $row_name['id'];
        $passwrd = $row_name['password'];

        if($passwrd != $pass){
            echo "<script>alert('Incorrect Password.');</script>";
        }
        else{
            $query =  $query = "UPDATE orders SET status = 3 WHERE payment_reference='" . $_POST['id'] . "'";
            $result = mysqli_query($conn,$query);

            $query = "UPDATE payments SET payment_method_id = '1' WHERE payment_reference='" . $_POST['id'] . "'";
            $result = mysqli_query($conn,$query);

            //var_dump($query);
            $result = mysqli_query($conn,$query);
            if($result){
                unset($_POST['txtPassword']);
                $_POST['txtPassword'] = "";
            }
        }        
    }else{
        echo "<script>alert('Incorrect Password.');</script>";
    }


}
/*
if(isset($_GET) && isset($_GET['r'])){
//void
    $query = "UPDATE orders SET status = 3 WHERE payment_reference='" . $_GET['r'] . "'";
    $result = mysqli_query($conn,$query);

    $query = "UPDATE payments SET payment_method_id = '1' WHERE payment_reference='" . $_GET['r'] . "'";
    $result = mysqli_query($conn,$query);
}*/
if(isset($_GET) && isset($_GET['c'])){
//cancel void
    $query = "UPDATE orders SET status = 1 WHERE payment_reference='" . $_GET['c'] . "'";
    $result = mysqli_query($conn,$query);

    $query = "UPDATE payments SET payment_method_id = '0' WHERE payment_reference='" . $_GET['c'] . "'";
    $result = mysqli_query($conn,$query);
 
}
$query = "select  payment_reference, table_id, status, created_at, user_id from  orders WHERE  created_at BETWEEN '". $startDate . "' AND '" . $endDate . "'  GROUP BY payment_reference" ;
//$query = "select payment_reference, table_id, status, created_at, user_id from orders WHERE created_at BETWEEN '2025-02-01 09:00:00' AND '2025-02-03 14:01:24' GROUP BY payment_reference" ;
//var_dump($query); 
$query_run = mysqli_query($conn, $query);
        if(mysqli_num_rows($query_run) > 0){ ?>
            <table id="report" class="table table-striped table-bordered" style="width:100%; "  border=1 >
            <thead>
                <tr>
                    <th>Date Time</th>                
                   <th style="width:15%;">Reference</th>    
                    <th>Table</th>                
                    <th>Status</th>   
                    <th>User</th>
                    <th>&nbsp;</th>               
                    
                </tr>
            </thead>
            <tbody>
            <?php foreach($query_run as $a){ 

                if($a['payment_reference'] != ""  && $a['created_at'] != ""){ //check if already paid
                
                $table_num = explode("_", $a['table_id']);
                $query_table = "select name from table_category WHERE id = '".$table_num[0]. "'";
                $query_run_table = mysqli_query($conn, $query_table);
                $row_table = mysqli_fetch_array($query_run_table);
                $status="";


                $query_cashier = "SELECT name from users WHERE id = '" .$a['user_id']."'";
                $query_run_table = mysqli_query($conn, $query_cashier);
                $row_cashier = mysqli_fetch_array($query_run_table);
                

                if($a['status'] == 1){
                    $status="<span style='color: green;'>Paid</span>";
                }elseif($a['status'] == 2){
                    $status="<span style='color: red;'>Cancelled</span>";
                }elseif($a['status'] == 0){
                    $status="<span style='color: blue;'>Unpaid</span>";
                }elseif($a['status'] == 3){    
                    $status="<span style='color: red;'>Void</span>";
                } else{}

                ?>
                <tr>
                <td><?= $a['created_at']; ?></td> 
                <td><?= $a['payment_reference']; ?></td>                                                            
                <td><?= $row_table['name'] . ' ' . $table_num[1]?></td>
                <td><?= $status?></td>
                <td><?= $row_cashier['name'];?></td>
                
                
                
                
                <?php
                //urls
                $urlOrder="#ViewOrders_".$a['table_id'] . "_" . $a['payment_reference'];
                $url="printBill.php?id=".$a['table_id'] . "&r=" . $a['payment_reference'];
                $urlVoid="?r=" . $a['payment_reference'];
                $urlCVoid="?c=" . $a['payment_reference'];
                ?>
                <!-- VIEW ORDERS -->
                
                <td>
                <?php if($a['status'] != 3){ ?>
                <a class="btn btn-dark  " style="background-color:black;" onclick="window.open('<?=$url?>','print_popup','width=1000,height=800');">Print Receipt</a>
                
                <a class="btn btn-danger btn-sm" id="edit" href="<?php echo '#editVoid'.$a['payment_reference']; ?>" data-toggle="modal" data-target="<?php echo '#editVoid'.$a['payment_reference']; ?>">VOID</a> 
                  <div class="modal fade" id="<?php echo 'editVoid'.$a['payment_reference']; ?>" tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'> 
                                                    <div class='modal-dialog' role='document'>
                                                        <div class='modal-content'>
                                                            <div class='modal-header'>
                                                                <h5 class='modal-title' id='exampleModalLabel'>Void Transaction # (<?php echo $a['payment_reference']; ?>)</h5>
                                                            </div>
                                                            <form action="" method="POST">
                                                            <input type="hidden" name="id" id="id" value="<?php echo $a['payment_reference'];?>">
                                                            <div class="modal-body">
                                                            Enter Password: &nbsp; <input class="form-control"  type="password" name="txtPassword"   required>
                                                            </div>
                                                                    <div class='modal-footer'>
                                                                    <button class='btn btn-dark btn-sm' type='button' data-dismiss='modal'>Cancel</button>
                                                                    <input type="submit" class="btn btn-danger btn-sm" value="VOID">
                                                                    </div>
                                                                </div>
                                                                </div>
                                                            </form>
                                                </div>
                                                
                <?php }
                 if($a['status'] == 3){ ?>
                <a class="btn " style=";background-color:#ffc107;border-color:#ffc107;" onclick="location.href='<?=$urlCVoid?>';">Undo Void</a>
                <?php } ?>
                
                </td> 



                          <?php }
                                        }
                                    }
                                   // else
                                   // {
                                       // echo "<h5> No Record Found </h5>";
                                   // }
                                ?>
                                </tbody>
                                </table>
                                <?php// }     ?>


<?php include 'footer.php'; ?>